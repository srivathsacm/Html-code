import { useEffect } from 'react';

export const useLocalStorage = (key, state, setState) => {
  useEffect(() => {
    const stored = localStorage.getItem(key);
    if (stored) setState(JSON.parse(stored));
  }, [key]);

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);
};
