
import React, { useReducer, useCallback, useState } from 'react';
import { patientReducer } from './reducer/patientReducer';
import { useLocalStorage } from './hooks/useLocalStorage';
import { PatientForm } from './components/PatientForm';
import { PatientList } from './components/PatientList';
import { v4 as uuidv4 } from 'uuid';

export const App = () => {
  
  const [patients, dispatch] = useReducer(patientReducer, []);

  
  useLocalStorage('patients', patients, dispatch);

  
  const [patientToEdit, setPatientToEdit] = useState(null);

  const handleAdd = useCallback((patient) => {
    if (patient.id) {
  
      dispatch({ type: 'UPDATE_PATIENT', payload: patient });
    } else {
      
      dispatch({ type: 'ADD_PATIENT', payload: { ...patient, id: uuidv4() } });
    }
    setPatientToEdit(null);
  }, []);

  const handleEdit = useCallback((patient) => {
    setPatientToEdit(patient);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleDelete = useCallback((id) => {
    if (window.confirm('Are you sure you want to delete this patient?')) {
      dispatch({ type: 'DELETE_PATIENT', payload: id });
    }
  }, []);

  const containerStyle = {
    maxWidth: '900px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
    color: '#1298e1ff',
  };

  const headerStyle = {
    textAlign: 'center',
    marginBottom: '20px',
  };

  return (
    <div style={containerStyle}>
      <h1 style={headerStyle}>Healthcare Dashboard</h1>
      <PatientForm onSubmit={handleAdd} patientToEdit={patientToEdit} />
      <PatientList patients={patients} onEdit={handleEdit} onDelete={handleDelete} />
    </div>
  );
};

export default App;
