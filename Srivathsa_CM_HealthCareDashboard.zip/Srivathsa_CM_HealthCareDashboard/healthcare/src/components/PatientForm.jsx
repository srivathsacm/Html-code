
import React, { useEffect } from 'react';
import { useForm } from '../hooks/useForm';

export const PatientForm = React.memo(({ onSubmit, patientToEdit }) => {
  const { values, handleChange, resetForm, setValues } = useForm({
    id: '',
    name: '',
    age: '',
    symptoms: '',
    appointmentDate: '',
    priority: 'Normal',
  });

  useEffect(() => {
    if (patientToEdit) {
      const isSame = JSON.stringify(values) === JSON.stringify(patientToEdit);
      if (!isSame) {
        setValues(patientToEdit);
      }
    } else {
      resetForm();
    }
  }, [patientToEdit]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!values.name || !values.age) {
      alert('Name and age are required');
      return;
    }
    onSubmit(values);
    resetForm();
  };

  return (
    <form onSubmit={handleSubmit} style={{
      marginBottom: '20px',
      padding: '20px',
      border: '1px solid #ccc',
      borderRadius: '8px',
      backgroundColor: '#f9f9f9',
    }}>
      <div style={{ marginBottom: '10px' }}>
        <label style={{ display: 'block', marginBottom: '4px' }}>Name:</label>
        <input
          name="name"
          value={values.name}
          onChange={handleChange}
          style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
        />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <label style={{ display: 'block', marginBottom: '4px' }}>Age:</label>
        <input
          name="age"
          type="number"
          value={values.age}
          onChange={handleChange}
          style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
        />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <label style={{ display: 'block', marginBottom: '4px' }}>Symptoms:</label>
        <textarea
          name="symptoms"
          value={values.symptoms}
          onChange={handleChange}
          style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
        />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <label style={{ display: 'block', marginBottom: '4px' }}>Appointment Date:</label>
        <input
          name="appointmentDate"
          type="date"
          value={values.appointmentDate}
          onChange={handleChange}
          style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
        />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <label style={{ display: 'block', marginBottom: '4px' }}>Priority:</label>
        <select
          name="priority"
          value={values.priority}
          onChange={handleChange}
          style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
        >
          <option>Normal</option>
          <option>High</option>
          <option>Critical</option>
        </select>
      </div>
      <button type="submit" style={{
        padding: '10px 20px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer'
      }}>
        {patientToEdit ? 'Update Patient' : 'Add Patient'}
      </button>
    </form>
  );
});
