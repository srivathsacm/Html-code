
import React, { useMemo, useState } from 'react';
import { PatientCard } from './PatientCard';

export const PatientList = React.memo(({ patients, onEdit, onDelete }) => {
  const [search, setSearch] = useState('');
  const [filterPriority, setFilterPriority] = useState('');

  const handleSearchChange = (e) => setSearch(e.target.value);
  const handlePriorityChange = (e) => setFilterPriority(e.target.value);

  
  const filtered = useMemo(() => {
    let list = patients;
    if (search) {
      const lower = search.toLowerCase();
      list = list.filter(p => p.name.toLowerCase().includes(lower));
    }
    if (filterPriority) {
      list = list.filter(p => p.priority === filterPriority);
    }
    return list;
  }, [patients, search, filterPriority]);

  return (
    <div style={{ marginTop: '20px' }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', marginBottom: '16px', gap: '8px' }}>
        <input
          placeholder="Search by name"
          value={search}
          onChange={handleSearchChange}
          style={{ padding: '8px', flex: '1 1 200px', boxSizing: 'border-box' }}
        />
        <select
          value={filterPriority}
          onChange={handlePriorityChange}
          style={{ padding: '8px', flex: '1 1 200px', boxSizing: 'border-box' }}
        >
          <option value="">All Priorities</option>
          <option value="Normal">Normal</option>
          <option value="High">High</option>
          <option value="Critical">Critical</option>
        </select>
      </div>

      {filtered.length > 0 ? (
        filtered.map(p => (
          <PatientCard key={p.id} patient={p} onEdit={onEdit} onDelete={onDelete} />
        ))
      ) : (
        <p style={{ textAlign: 'center', color: '#666' }}>No patients found</p>
      )}
    </div>
  );
});
