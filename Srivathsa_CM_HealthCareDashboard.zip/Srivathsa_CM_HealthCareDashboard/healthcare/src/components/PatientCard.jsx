
import React from 'react';

export const PatientCard = React.memo(({ patient, onEdit, onDelete }) => {
  const { id, name, age, symptoms, appointmentDate, priority } = patient;

  const cardStyle = {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '16px',
    marginBottom: '12px',
    backgroundColor: '#2d0928ff',
    boxShadow: '2px 2px 6px rgba(25, 220, 51, 0.05)'
  };

  const headerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '8px',
  };

  const priorityColor = priority === 'Critical' ? '#dc3545'
                      : priority === 'High' ? '#ffc107'
                      : '#28a745';

  return (
    <div style={cardStyle}>
      <div style={headerStyle}>
        <h3 style={{ margin: 0 }}>{name} (Age: {age})</h3>
        <span style={{
          padding: '4px 8px',
          backgroundColor: priorityColor,
          color: '#fff',
          borderRadius: '4px',
          fontSize: '0.9em'
        }}>{priority}</span>
      </div>
      <div style={{ marginBottom: '8px' }}>
        <strong>Symptoms:</strong> {symptoms}
      </div>
      <div style={{ marginBottom: '12px' }}>
        <strong>Appointment:</strong> {appointmentDate}
      </div>
      <div>
        <button onClick={() => onEdit(patient)} style={{
          marginRight: '8px',
          padding: '6px 12px',
          backgroundColor: '#17a2b8',
          color: '#fff',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }}>Edit</button>
        <button onClick={() => onDelete(id)} style={{
          padding: '6px 12px',
          backgroundColor: '#dc354bff',
          color: '#fff',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }}>Delete</button>
      </div>
    </div>
  );
});
