export const patientReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_PATIENT':
      return [...state, action.payload];
    case 'UPDATE_PATIENT':
      return state.map(p => p.id === action.payload.id ? action.payload : p);
    case 'DELETE_PATIENT':
      return state.filter(p => p.id !== action.payload);
    case 'SET_PATIENTS':
      return action.payload;
    default:
      return state;
  }
};
