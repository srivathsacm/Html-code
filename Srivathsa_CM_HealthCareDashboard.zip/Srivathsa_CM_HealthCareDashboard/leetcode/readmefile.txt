Generate Parentheses

This repository contains a Java solution for the well-known “Generate Parentheses” problem.  
Given an integer n, the code generates all combinations of n pairs of well-formed parentheses.  
We use a backtracking approach to build strings character by character.  
We track counts of open and close parentheses, ensuring at no point the closes exceed opens.  
Once the current string has length 2·n, it is added to the result list.  
The solution runs in time proportional to the n-th Catalan number and uses O(n) space for recursion.  
To use: instantiate `Solution` and call `generateParenthesis(n)` with your desired n.  
Example: for n=3 you’ll get ["((()))","(()())","(())()","()(())","()()()"].  
Feel free to explore variations, add tests, or adapt the logic to other languages.  
Happy coding!
